---
name: SIHS Mobile
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4a3d'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7b6c'
  outline-variant: '#bdcaba'
  surface-tint: '#006e2d'
  primary: '#006b2c'
  on-primary: '#ffffff'
  primary-container: '#00873a'
  on-primary-container: '#f7fff2'
  inverse-primary: '#62df7d'
  secondary: '#226d00'
  on-secondary: '#ffffff'
  secondary-container: '#8afd5d'
  on-secondary-container: '#257400'
  tertiary: '#8d4b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#b15f00'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#7ffc97'
  primary-fixed-dim: '#62df7d'
  on-primary-fixed: '#002109'
  on-primary-fixed-variant: '#005320'
  secondary-fixed: '#8afd5d'
  secondary-fixed-dim: '#6fdf43'
  on-secondary-fixed: '#052100'
  on-secondary-fixed-variant: '#185200'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
  display-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Geist
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an institutional yet dynamic identity for mobile technical education and field management in Colombia. It bridges institutional trust with modern, agile, digital utility. Built upon Material Design 3 guidelines, the aesthetic is clean, purposeful, and vibrant—balancing civic reliability with contemporary clarity.

The visual style is **Corporate / Modern** elevated by tactile institutional cues: crisp typography, deliberate tonal contrasts, rounded physical components, and a pervasive sense of clarity suitable for diverse outdoor and indoor field scenarios. The interface prioritizes scannability, rapid micro-interactions, high accessibility ratios, and unmistakable brand resonance across every screen.

## Colors

The palette directly honors Colombian institutional identity through an energetic, nature-rooted green spectrum paired with slate neutrals.

### Light Theme
- **Primary:** `#16a34a` (Verde SENA) — High-impact actions, key landmarks, active interactive states.
  - *On Primary:* `#ffffff`
  - *Primary Container:* `#dcfce7`
  - *On Primary Container:* `#14532d`
- **Secondary:** `#39a900` — Accent actions, badges, tertiary navigation tabs, and system confirmations.
  - *On Secondary:* `#ffffff`
  - *Secondary Container:* `#eaf7ec`
  - *On Secondary Container:* `#14532d`
- **Tertiary:** `#d97706` — System warnings, scheduled tasks, operational notices, and pending verifications.
  - *Tertiary Container:* `#fef3c7`
- **Error:** `#dc2626` — Validation failures, critical alerts, destructive triggers.
  - *Error Container:* `#fee2e2`
- **Surface Foundations:**
  - *Surface:* `#f8fafc`
  - *Surface Container / Dim:* `#e2e8f0`
  - *On Surface:* `#0f172a`
  - *On Surface Variant:* `#475569`

### Dark Theme Transitions
- **Primary:** `#4ade80` (On-Primary: `#052e13`, Primary Container: `#14532d`)
- **Surface:** `#0f172a` (Surface Container: `#1e293b`, On-Surface: `#f1f5f9`)

Color application relies heavily on tonal containers (`#dcfce7`, `#eaf7ec`, `#fef3c7`) rather than high-density solid fills for standard surfaces to maintain visual breathing room and reduce eye fatigue.

## Typography

Typography establishes an authoritative yet accessible cadence using **Hanken Grotesk** for structured, structural headlining and **Geist** for precise, neutral data presentation and long-form instructional copy.

- **Hanken Grotesk (600/700):** Drives all landmark screen titles, module sections, metric callouts, and system app bars. Its geometric baseline gives strong architectural structure to educational modules.
- **Geist (400/500/600):** Powers high-density mobile tables, data readouts, body instructions, input field values, and system badges. Its monoline engineering clarity ensures zero character confusion even on low-cost mobile displays under bright sunlight.
- Always use `display-lg-mobile` instead of full display scales when rendering hero headers on standard mobile portrait displays under 400px width.

## Layout & Spacing

The layout adheres to a flexible 4-column grid on mobile (<600px), transitioning to an 8-column layout on tablets (600px–1023px) and 12-column on desktop/landscape dashboards (≥1024px).

- **Margins:** 16px (`1rem`) on handheld devices to maximize actionable touch targets; expanding to 24px (`1.5rem`) on tablets.
- **Gutters:** 16px (`1rem`) uniform spacing between grid modules, cards, and vertical list structures.
- **Vertical Spacing Rhythm:** Component interiors leverage a 4px base step (`space-xs: 4px`, `space-sm: 8px`, `space-md: 16px`, `space-lg: 24px`, `space-xl: 32px`).
- Form elements and interaction items must maintain a minimum bounding height of 48px to accommodate ergonomic thumb zones.

## Elevation & Depth

Visual hierarchy uses Material Design 3 ambient layered surfaces combined with soft structural shadows. Rather than sharp skeuomorphic shadows or completely flat planes, depth is communicated through a combination of subtle surface container tinting and ambient light diffusion.

- **Level 0 (Flat):** Main background canvas (`#f8fafc` Light, `#0f172a` Dark). No shadow.
- **Level 1 (Cards & Modules):** Applied to resting content cards, lists, and input areas. Defined by `box-shadow: 0px 1px 3px rgba(15, 23, 42, 0.08), 0px 1px 2px rgba(15, 23, 42, 0.04)`. Accompanied by a delicate 1px boundary stroke using `#e2e8f0` (or `#334155` in dark mode) to preserve edge definition under varied backlights.
- **Level 2 (Floating Sheets, App Bars, Bottom Nav):** Floating filter pills, bottom navigation bars, and persistent action drawers. Defined by `box-shadow: 0px 4px 12px rgba(15, 23, 42, 0.08), 0px 2px 4px rgba(15, 23, 42, 0.04)`.
- **Level 3 (Modals & Bottom Drawers):** Modal sheets, contextual pickers, and high-priority inspection dialogs. Shadow: `0px 12px 24px rgba(15, 23, 42, 0.14)`.

## Shapes

The design system employs a calibrated multi-radius hierarchy tailored to ergonomic mobile interaction:

- **12px Radius (`rounded-md` / medium):** Standard across inputs, text areas, standard card containers, and contextual list item cards.
- **16px Radius (`rounded-lg` / large):** Applied to high-level surfaces, modal dialogs, bottom sheets, banner cards, and grouped task containers.
- **Full Pill (`rounded-full` / 9999px):** Strictly reserved for action buttons (Filled, Tonal, Outlined), interaction chips, notification tags, and FAB triggers. This creates an immediate cognitive distinction between container bounds and interactive touch actions.

## Components

### Buttons
- **Filled Button:** Pill-shaped (`rounded-full`), min-height 48px, horizontal padding 24px. Primary background `#16a34a` with text in `#ffffff`. Text uses `label-lg` (Geist 600).
- **Tonal Button:** Secondary/supporting actions. Pill-shaped, Primary Container background `#dcfce7` with text `#14532d`.
- **Outlined Button:** 1.5px border in `#16a34a`, transparent background, text `#16a34a`.
- **Icon Buttons:** 48x48px touch target with a centered 24px icon.

### Chips & Badges
- **Status & Filter Chips:** Height 32px, pill-shaped (`rounded-full`). Padding 12px horizontally.
- **Active State:** Secondary Container background `#eaf7ec`, border 1px solid `#39a900`, text `#14532d` using `label-md`.
- **Inactive State:** Surface Container `#e2e8f0`, text `#475569`.

### Cards
- **Structural Card:** 12px corner radius, background `#ffffff` (Light) / `#1e293b` (Dark), bordered with 1px `#e2e8f0`. Elevation Level 1. Padding 16px.
- **Interactive Action Card:** Includes a 4px left-hand border accent in `#16a34a` to designate active technical modules or pending records.

### Input Fields
- **Text Inputs & Dropdowns:** 12px corner radius, min-height 52px. Background `#ffffff`, border 1px solid `#cbd5e1`.
- **Focused State:** 2px border in `#16a34a`, background `#ffffff`, subtle outer ring shadow in `rgba(22, 163, 74, 0.15)`. Floating label in `label-md`.
- **Error State:** Border `#dc2626`, error message rendered in `label-sm` with Error color `#dc2626`.

### Checkboxes & Radio Buttons
- **Checkboxes:** 20x20px with 4px corner radius. Active state filled `#16a34a` with white checkmark. Inactive state bordered with 2px `#94a3b8`.
- **Radio Buttons:** 20x20px circle. Active state 2px ring `#16a34a` containing an 8px inner dot `#16a34a`.

### Lists & Navigation
- **Navigation Bar (Bottom):** Height 64px, surface `#ffffff` (Elevation Level 2), top border 1px `#e2e8f0`. Active item uses a pill-shaped indicator `#dcfce7` behind icons.
- **Data Lists:** Separated by 8px gaps or 1px dividers `#f1f5f9`. Content titles set in Hanken Grotesk `title-md`, secondary descriptors in Geist `body-sm`.